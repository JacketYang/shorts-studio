import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { buildCatalog, CATEGORIES } from './catalog/catalog';
import type { VideoSpec } from './engine/types';
import { buildScene, themeOf } from './scenes';
import { renderVideo, webCodecsAvailable } from './engine/render';
import { buildZip, isEmbedded, saveUrl } from './engine/download';
import { Card } from './components/Card';
import type { Result } from './components/Card';
import { Preview } from './components/Preview';

const load = (k: string): string[] => {
  try { return JSON.parse(localStorage.getItem(k) || '[]'); } catch { return []; }
};
const save = (k: string, v: Iterable<string>) => {
  try { localStorage.setItem(k, JSON.stringify([...v])); } catch { /* noop */ }
};

const publishText = (specs: VideoSpec[], ext: (s: VideoSpec) => string) =>
  specs.map((s, i) => `#${i + 1}  文件：${s.filename}.${ext(s)}\n标题：${s.title}\n\n描述：\n${s.description}\n\n标签：${s.tags.join(', ')}\n`).join('\n' + '='.repeat(60) + '\n\n');

export default function App() {
  const recipes = useMemo(() => buildCatalog(), []);
  const [variants, setVariants] = useState<Record<string, number>>({});
  const specs = useMemo(() => recipes.map((r) => r.spec(variants[r.id] ?? 0)), [recipes, variants]);

  const [cat, setCat] = useState('all');
  const [q, setQ] = useState('');
  const [hidePub, setHidePub] = useState(false);
  const [res, setRes] = useState<'1080' | '720'>('1080');
  const [fps, setFps] = useState<30 | 60>(30);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [published, setPublished] = useState<Set<string>>(new Set(load('published')));
  const [downloaded, setDownloaded] = useState<Set<string>>(new Set(load('downloaded')));
  const [results, setResults] = useState<Record<string, Result>>({});
  const [jobs, setJobs] = useState<Record<string, { stage: string; p: number }>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [queued, setQueued] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState<VideoSpec | null>(null);
  const [zip, setZip] = useState<{ url: string; name: string; n: number; mb: string } | null>(null);
  const [zipping, setZipping] = useState(false);
  const [showInsight, setShowInsight] = useState(false);
  const [limit, setLimit] = useState(36);

  const queue = useRef<{ spec: VideoSpec; auto: boolean }[]>([]);
  const running = useRef(false);
  const token = useRef({ cancelled: false });
  const opts = useRef({ res, fps });
  opts.current = { res, fps };

  const markDownloaded = useCallback((id: string) => {
    setDownloaded((d) => { const n = new Set(d); n.add(id); save('downloaded', n); return n; });
  }, []);

  const generate = useCallback(async (spec: VideoSpec, auto: boolean) => {
    const { res: rs, fps: f } = opts.current;
    const width = rs === '1080' ? 1080 : 720;
    const height = rs === '1080' ? 1920 : 1280;
    setErrors((e) => { const n = { ...e }; delete n[spec.id]; return n; });
    setJobs((j) => ({ ...j, [spec.id]: { stage: '构建场景', p: 0 } }));
    try {
      await new Promise((r) => setTimeout(r, 20));
      const scene = buildScene(spec);
      const out = await renderVideo(scene, themeOf(spec), spec.hook, {
        width, height, fps: f, bitrate: (rs === '1080' ? 7e6 : 3.5e6) * (f === 60 ? 1.4 : 1),
        token: token.current,
        onProgress: (p, stage) => setJobs((j) => ({ ...j, [spec.id]: { stage, p } })),
      });
      const url = URL.createObjectURL(out.blob);
      setResults((r) => ({ ...r, [spec.id]: { blob: out.blob, url, ext: out.ext, size: out.blob.size, note: out.note } }));
      if (auto) {
        saveUrl(url, `${spec.filename}.${out.ext}`);
        markDownloaded(spec.id);
      }
    } catch (e) {
      const m = (e as Error).message;
      if (m !== 'cancelled') setErrors((er) => ({ ...er, [spec.id]: m }));
    } finally {
      setJobs((j) => { const n = { ...j }; delete n[spec.id]; return n; });
    }
  }, [markDownloaded]);

  const pump = useCallback(async () => {
    if (running.current) return;
    running.current = true;
    setBusy(true);
    while (queue.current.length) {
      const job = queue.current.shift()!;
      token.current = { cancelled: false };
      await generate(job.spec, job.auto);
      setQueued((qs) => { const n = new Set(qs); n.delete(job.spec.id); return n; });
    }
    running.current = false;
    setBusy(false);
  }, [generate]);

  const enqueue = useCallback((spec: VideoSpec, auto: boolean) => {
    if (queue.current.some((j) => j.spec.id === spec.id)) return;
    queue.current.push({ spec, auto });
    setQueued((qs) => new Set(qs).add(spec.id));
    pump();
  }, [pump]);

  const cancelAll = () => {
    token.current.cancelled = true;
    const ids = queue.current.map((j) => j.spec.id);
    queue.current = [];
    setQueued((qs) => { const n = new Set(qs); ids.forEach((i) => n.delete(i)); return n; });
  };

  const filtered = useMemo(() => {
    const kw = q.trim().toLowerCase();
    return specs.filter((s) => (cat === 'all' || s.category === cat) && (!kw || s.title.toLowerCase().includes(kw) || s.engine.includes(kw)) && !(hidePub && published.has(s.id.split('~')[0])));
  }, [specs, cat, q, hidePub, published]);

  useEffect(() => { setLimit(36); }, [cat, q, hidePub]);
  const shown = filtered.slice(0, limit);

  const toggle = (id: string) => setSelected((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  const togglePub = (id: string) => {
    const base = id.split('~')[0];
    setPublished((s) => { const n = new Set(s); if (n.has(base)) n.delete(base); else n.add(base); save('published', n); return n; });
  };

  const selSpecs = specs.filter((s) => selected.has(s.id));
  const doneSel = selSpecs.filter((s) => results[s.id]);
  const todoSel = selSpecs.filter((s) => !results[s.id]);

  const makeZip = async () => {
    setZipping(true);
    try {
      const list = doneSel.length ? doneSel : specs.filter((s) => results[s.id]);
      const files: { name: string; blob?: Blob; text?: string }[] = [];
      for (const s of list) {
        const r = results[s.id];
        files.push({ name: `${s.filename}.${r.ext}`, blob: r.blob });
        files.push({ name: `${s.filename}.txt`, text: `${s.title}\n\n${s.description}\n\nTags: ${s.tags.join(', ')}\n` });
      }
      files.push({ name: '发布文案汇总.txt', text: publishText(list, (s) => results[s.id].ext) });
      const blob = await buildZip(files);
      if (zip) URL.revokeObjectURL(zip.url);
      const url = URL.createObjectURL(blob);
      const name = `shorts-batch-${new Date().toISOString().slice(0, 10)}.zip`;
      setZip({ url, name, n: list.length, mb: (blob.size / 1048576).toFixed(1) });
      saveUrl(url, name);
      list.forEach((s) => markDownloaded(s.id));
    } finally {
      setZipping(false);
    }
  };

  const exportTxt = () => {
    const list = selSpecs.length ? selSpecs : filtered;
    const blob = new Blob(['\ufeff' + publishText(list, (s) => results[s.id]?.ext ?? 'mp4')], { type: 'text/plain;charset=utf-8' });
    saveUrl(URL.createObjectURL(blob), 'titles-descriptions.txt');
  };

  const jobId = Object.keys(jobs)[0];
  const job = jobId ? jobs[jobId] : undefined;
  const jobSpec = jobId ? specs.find((s) => s.id === jobId) : undefined;
  const totalDone = Object.keys(results).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <header className="border-b border-slate-800 bg-gradient-to-r from-indigo-950 via-slate-900 to-sky-950 px-4 py-5">
        <div className="mx-auto flex max-w-[1500px] flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="text-2xl font-black tracking-tight md:text-3xl">🎬 Shorts 爆款视频工厂</h1>
            <p className="mt-1 text-sm text-slate-300">共 <b className="text-sky-300">{specs.length}</b> 条可直接发布的竖屏视频（1080×1920 · MP4 · 带音乐）· 点“生成并下载”→ 得到视频文件 → 复制标题/描述即可发布</p>
          </div>
          <div className="flex gap-2 text-xs">
            <span className="rounded-lg bg-slate-800 px-3 py-2">已生成 <b className="text-emerald-300">{totalDone}</b></span>
            <span className="rounded-lg bg-slate-800 px-3 py-2">已下载 <b className="text-sky-300">{downloaded.size}</b></span>
            <span className="rounded-lg bg-slate-800 px-3 py-2">已发布 <b className="text-amber-300">{published.size}</b></span>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-[1500px] px-4 py-4">
        {isEmbedded() && (
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-amber-500/50 bg-amber-950/60 p-3 text-sm text-amber-200">
            <span>⚠️ 检测到页面在嵌入窗口(iframe)中运行，浏览器可能拦截下载。建议点右侧按钮在独立标签页打开后再生成/下载。</span>
            <button onClick={() => window.open(window.location.href, '_blank')} className="rounded-lg bg-amber-400 px-3 py-1.5 font-bold text-black">在新标签页打开</button>
          </div>
        )}
        {!webCodecsAvailable() && (
          <div className="mb-3 rounded-xl border border-rose-500/50 bg-rose-950/60 p-3 text-sm text-rose-200">当前浏览器不支持 WebCodecs，将使用“实时录制”模式（耗时等于视频时长，需保持页面在前台）。推荐使用最新版 Chrome / Edge。</div>
        )}

        <div className="mb-3 rounded-xl border border-slate-800 bg-slate-900/70 p-3">
          <button onClick={() => setShowInsight((s) => !s)} className="flex w-full items-center justify-between text-left text-sm font-bold text-sky-300">
            <span>📊 你的频道数据洞察（本批视频的设计依据）</span><span>{showInsight ? '▲' : '▼'}</span>
          </button>
          {showInsight && (
            <div className="mt-2 grid gap-2 text-[13px] leading-relaxed text-slate-300 md:grid-cols-2">
              <ul className="list-disc space-y-1 pl-5">
                <li>总播放 <b>29,060</b>，前几名全是“<b>球体 / 物理 + 旋律</b>”：Canon in D 木琴球 1,896、Ode to Joy 1,544、Für Elise 1,105、山魔王越来越快 1,079。→ 旋律类做了最多（约 {specs.filter((s) => s.category === 'music').length} 条）。</li>
                <li><b>数字 + 悬念</b>标题表现好：40 Pendulums 1,562、16 Balls 4 Bins 系列都过千、Pi 碰撞 1,293、排序之声 1,269。→ 小球分拣 / 钟摆 / 圆周率 / 排序算法都保留并扩展。</li>
                <li>完播率高的片子时长多在 <b>13–45 秒</b>，且结尾有“揭晓”。本批视频全部 14–35 秒，并带最终结果画面。</li>
              </ul>
              <ul className="list-disc space-y-1 pl-5">
                <li>纯讲解题（汤放冰箱 24、月球为什么不掉 33、借力飞行 35）几乎没人看 → <b>本批不再出讲解型</b>，全部是“看了就停不下来”的可视化。</li>
                <li>同一玩法重复发太多会互相抢流量 → 本批用 19 种不同玩法 × 多种布局/配色/曲目，并有“🎲 换一版”随时再出变体。</li>
                <li>建议节奏：每天 1–3 条，不同类型交替发；用“已发布”勾选记录进度（浏览器本地保存）。</li>
              </ul>
            </div>
          )}
        </div>

        <div className="sticky top-0 z-30 -mx-4 mb-4 space-y-2 border-b border-slate-800 bg-slate-950/95 px-4 py-3 backdrop-blur">
          <div className="flex flex-wrap items-center gap-2">
            <button onClick={() => setCat('all')} className={`rounded-full px-3 py-1.5 text-xs font-bold ${cat === 'all' ? 'bg-sky-500 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}>全部 ({specs.length})</button>
            {CATEGORIES.map((c) => (
              <button key={c.id} onClick={() => setCat(c.id)} className={`rounded-full px-3 py-1.5 text-xs font-bold ${cat === c.id ? 'bg-sky-500 text-white' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'}`}>
                {c.label} ({specs.filter((s) => s.category === c.id).length})
              </button>
            ))}
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="搜索标题…" className="ml-auto w-44 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs outline-none focus:border-sky-500" />
            <label className="flex cursor-pointer items-center gap-1 text-xs text-slate-300"><input type="checkbox" checked={hidePub} onChange={(e) => setHidePub(e.target.checked)} className="accent-amber-500" />隐藏已发布</label>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <select value={res} onChange={(e) => setRes(e.target.value as '1080' | '720')} className="rounded-lg border border-slate-700 bg-slate-900 px-2 py-1.5">
              <option value="1080">1080×1920 高清</option>
              <option value="720">720×1280 快速/小文件</option>
            </select>
            <select value={fps} onChange={(e) => setFps(Number(e.target.value) as 30 | 60)} className="rounded-lg border border-slate-700 bg-slate-900 px-2 py-1.5">
              <option value={30}>30 fps</option>
              <option value={60}>60 fps</option>
            </select>
            <span className="mx-1 text-slate-600">|</span>
            <button onClick={() => setSelected(new Set(filtered.map((s) => s.id)))} className="rounded-lg bg-slate-800 px-3 py-1.5 hover:bg-slate-700">全选当前列表 ({filtered.length})</button>
            <button onClick={() => setSelected(new Set(filtered.filter((s) => !results[s.id] && !published.has(s.id.split('~')[0])).slice(0, 10).map((s) => s.id)))} className="rounded-lg bg-slate-800 px-3 py-1.5 hover:bg-slate-700">选前10个未发布</button>
            <button onClick={() => setSelected(new Set())} className="rounded-lg bg-slate-800 px-3 py-1.5 hover:bg-slate-700">清空 ({selected.size})</button>
            <button disabled={!todoSel.length} onClick={() => todoSel.forEach((s) => enqueue(s, false))} className="rounded-lg bg-violet-600 px-3 py-1.5 font-bold text-white hover:bg-violet-500 disabled:opacity-40">批量生成 ({todoSel.length})</button>
            <button disabled={zipping || !totalDone} onClick={makeZip} className="rounded-lg bg-emerald-600 px-3 py-1.5 font-bold text-white hover:bg-emerald-500 disabled:opacity-40">{zipping ? '打包中…' : `📦 打包 ZIP 下载 (${doneSel.length || totalDone})`}</button>
            <button onClick={exportTxt} className="rounded-lg bg-slate-800 px-3 py-1.5 hover:bg-slate-700">导出标题/描述 TXT</button>
          </div>
          {zip && (
            <div className="flex flex-wrap items-center gap-2 rounded-lg bg-emerald-950/70 p-2 text-xs text-emerald-200">
              ✅ ZIP 已就绪：{zip.n} 个视频 · {zip.mb} MB（若未自动下载，请点右边按钮）
              <a href={zip.url} download={zip.name} className="rounded-lg bg-emerald-500 px-3 py-1.5 font-bold text-white">⬇ 下载 {zip.name}</a>
            </div>
          )}
          {(busy || queued.size > 0) && (
            <div className="flex flex-wrap items-center gap-3 rounded-lg bg-slate-900 p-2 text-xs">
              <span className="font-bold text-sky-300">{jobSpec ? `正在生成：${jobSpec.title.slice(0, 48)}` : '处理中…'}</span>
              {job && <span>{job.stage} {Math.round(job.p * 100)}%</span>}
              <div className="h-2 w-40 overflow-hidden rounded bg-slate-700"><div className="h-full bg-sky-400" style={{ width: `${(job?.p ?? 0) * 100}%` }} /></div>
              <span className="text-slate-400">队列剩余 {queued.size}</span>
              <button onClick={cancelAll} className="ml-auto rounded-lg bg-rose-600 px-3 py-1 font-bold text-white">取消</button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6">
          {shown.map((s) => (
            <Card
              key={s.id}
              spec={s}
              result={results[s.id]}
              job={jobs[s.id]}
              queued={queued.has(s.id) && !jobs[s.id]}
              error={errors[s.id]}
              selected={selected.has(s.id)}
              published={published.has(s.id.split('~')[0])}
              downloaded={downloaded.has(s.id)}
              busy={busy}
              onSelect={() => toggle(s.id)}
              onPublished={() => togglePub(s.id)}
              onGenerate={() => enqueue(s, true)}
              onReroll={() => {
                const base = s.id.split('~')[0];
                setVariants((v) => ({ ...v, [base]: (v[base] ?? 0) + 1 }));
                setSelected((sel) => { const n = new Set(sel); n.delete(s.id); return n; });
              }}
              onOpen={() => setPreview(s)}
              onDownloaded={() => markDownloaded(s.id)}
            />
          ))}
        </div>
        {shown.length < filtered.length && (
          <div className="py-6 text-center">
            <button onClick={() => setLimit((l) => l + 36)} className="rounded-xl bg-slate-800 px-6 py-3 text-sm font-bold hover:bg-slate-700">加载更多（{shown.length}/{filtered.length}）</button>
          </div>
        )}
        {filtered.length === 0 && <div className="py-20 text-center text-slate-500">没有符合条件的视频</div>}
        <footer className="mt-8 border-t border-slate-800 py-6 text-center text-xs text-slate-500">
          所有旋律均为公版曲目，音效由程序合成，画面由代码实时渲染，不含任何第三方素材。视频在你的浏览器本地生成，不会上传。
        </footer>
      </div>

      {preview && <Preview spec={preview} busy={busy} onClose={() => setPreview(null)} onGenerate={() => enqueue(preview, true)} />}
    </div>
  );
}

import { useState } from 'react';
import type { VideoSpec } from '../engine/types';
import { Thumb } from './Thumb';
import { CopyButton } from './CopyButton';
import { openInNewTab, saveWithPicker } from '../engine/download';

export interface Result {
  blob: Blob;
  url: string;
  ext: string;
  size: number;
  note: string;
}

interface Props {
  spec: VideoSpec;
  result?: Result;
  job?: { stage: string; p: number };
  queued: boolean;
  error?: string;
  selected: boolean;
  published: boolean;
  downloaded: boolean;
  busy: boolean;
  onSelect: () => void;
  onPublished: () => void;
  onGenerate: () => void;
  onReroll: () => void;
  onOpen: () => void;
  onDownloaded: () => void;
}

export function Card(p: Props) {
  const { spec, result, job } = p;
  const [open, setOpen] = useState(false);
  const [msg, setMsg] = useState('');
  const fname = `${spec.filename}.${result?.ext ?? 'mp4'}`;
  const mb = result ? (result.size / 1048576).toFixed(1) : '';
  const full = `${spec.title}\n\n${spec.description}\n\nTags: ${spec.tags.join(', ')}`;

  return (
    <div className={`flex flex-col gap-2 rounded-2xl border p-2.5 transition ${p.selected ? 'border-sky-400 bg-slate-800/90' : 'border-slate-700/70 bg-slate-800/50'} ${p.published ? 'opacity-60' : ''}`}>
      <div className="relative">
        <Thumb spec={spec} onOpen={p.onOpen} />
        <label className="absolute left-2 top-2 flex cursor-pointer items-center gap-1 rounded-full bg-black/60 px-2 py-1 text-[11px] text-white">
          <input type="checkbox" checked={p.selected} onChange={p.onSelect} className="accent-sky-500" /> 选择
        </label>
        <span className="absolute right-2 top-2 rounded-full bg-black/60 px-2 py-1 text-[11px] text-white">{spec.catLabel}</span>
        {(result || p.downloaded || p.published) && (
          <div className="absolute bottom-2 left-2 flex gap-1 text-[10px] font-bold">
            {result && <span className="rounded bg-emerald-500 px-1.5 py-0.5 text-white">已生成</span>}
            {p.downloaded && <span className="rounded bg-sky-500 px-1.5 py-0.5 text-white">已下载</span>}
            {p.published && <span className="rounded bg-amber-500 px-1.5 py-0.5 text-black">已发布</span>}
          </div>
        )}
      </div>
      <div className="line-clamp-2 min-h-[2.5rem] text-[13px] font-semibold leading-snug text-slate-100">{spec.title}</div>

      {job ? (
        <div className="rounded-lg bg-slate-900 p-2">
          <div className="mb-1 flex justify-between text-[11px] text-slate-300"><span>{job.stage}</span><span>{Math.round(job.p * 100)}%</span></div>
          <div className="h-2 overflow-hidden rounded bg-slate-700"><div className="h-full bg-gradient-to-r from-emerald-400 to-sky-400 transition-all" style={{ width: `${job.p * 100}%` }} /></div>
        </div>
      ) : p.queued ? (
        <div className="rounded-lg bg-slate-900 p-2 text-center text-xs text-slate-300">⏳ 排队中…</div>
      ) : result ? (
        <div className="flex flex-col gap-1.5">
          <a
            href={result.url}
            download={fname}
            onClick={p.onDownloaded}
            className="block rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 px-3 py-2.5 text-center text-sm font-bold text-white shadow hover:brightness-110"
          >
            ⬇ 下载 {result.ext.toUpperCase()}（{mb} MB）
          </a>
          <div className="flex gap-1.5 text-[11px]">
            <button
              className="flex-1 rounded-lg bg-slate-700 px-2 py-1.5 hover:bg-slate-600"
              onClick={async () => {
                try {
                  await saveWithPicker(result.blob, fname, result.ext);
                  p.onDownloaded();
                  setMsg('已保存 ✓');
                } catch (e) {
                  setMsg((e as Error).message.includes('abort') ? '' : '另存为不可用：' + (e as Error).message);
                }
              }}
            >
              另存为…
            </button>
            <button className="flex-1 rounded-lg bg-slate-700 px-2 py-1.5 hover:bg-slate-600" onClick={() => openInNewTab(result.url)}>新标签打开</button>
          </div>
          <div className="text-center text-[10px] text-slate-500">{result.note}</div>
        </div>
      ) : (
        <button onClick={p.onGenerate} className="rounded-xl bg-gradient-to-r from-violet-500 to-sky-500 px-3 py-2.5 text-sm font-bold text-white shadow hover:brightness-110">
          ⬇ 生成并下载
        </button>
      )}
      {p.error && <div className="rounded-lg bg-rose-950 p-2 text-[11px] text-rose-300">失败：{p.error}</div>}
      {msg && <div className="text-center text-[11px] text-amber-300">{msg}</div>}

      <div className="flex flex-wrap gap-1.5">
        <CopyButton text={spec.title} label="标题" />
        <CopyButton text={spec.description} label="描述" />
        <CopyButton text={spec.tags.join(', ')} label="标签" />
        <CopyButton text={full} label="全部" />
      </div>
      <div className="flex items-center justify-between gap-1 text-[11px] text-slate-300">
        <button onClick={p.onReroll} className="rounded-lg bg-slate-700/80 px-2 py-1 hover:bg-slate-600" title="换配色/标题/版式">🎲 换一版</button>
        <button onClick={() => setOpen((o) => !o)} className="rounded-lg bg-slate-700/80 px-2 py-1 hover:bg-slate-600">{open ? '收起文案' : '看文案'}</button>
        <label className="flex cursor-pointer items-center gap-1"><input type="checkbox" checked={p.published} onChange={p.onPublished} className="accent-amber-500" />已发布</label>
      </div>
      {open && <pre className="max-h-48 overflow-auto whitespace-pre-wrap rounded-lg bg-slate-900 p-2 text-[11px] leading-relaxed text-slate-300">{spec.description}{'\n\nTags: '}{spec.tags.join(', ')}</pre>}
    </div>
  );
}

import { useState } from 'react';
import { copyText } from '../engine/download';

export function CopyButton({ text, label, className = '' }: { text: string; label: string; className?: string }) {
  const [ok, setOk] = useState(false);
  return (
    <button
      onClick={async () => {
        const r = await copyText(text);
        setOk(r);
        setTimeout(() => setOk(false), 1400);
      }}
      className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${ok ? 'bg-emerald-500 text-white' : 'bg-slate-700 text-slate-100 hover:bg-slate-600'} ${className}`}
    >
      {ok ? '✓ 已复制' : label}
    </button>
  );
}

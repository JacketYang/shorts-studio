import { useEffect, useRef, useState } from 'react';
import type { VideoSpec } from '../engine/types';
import { buildScene, themeOf } from '../scenes';
import { startPreview } from '../engine/preview';
import { CopyButton } from './CopyButton';

export function Preview({ spec, onClose, onGenerate, busy }: { spec: VideoSpec; onClose: () => void; onGenerate: () => void; busy: boolean }) {
  const cv = useRef<HTMLCanvasElement>(null);
  const [sound, setSound] = useState(true);
  const [loading, setLoading] = useState(true);
  const [dur, setDur] = useState(0);

  useEffect(() => {
    setLoading(true);
    let handle: { stop: () => void } | null = null;
    let dead = false;
    const id = setTimeout(() => {
      if (dead || !cv.current) return;
      try {
        const sc = buildScene(spec);
        setDur(sc.duration);
        handle = startPreview(cv.current, sc, themeOf(spec), spec.hook, sound);
      } catch (e) {
        console.error(e);
      }
      setLoading(false);
    }, 40);
    return () => {
      dead = true;
      clearTimeout(id);
      handle?.stop();
    };
  }, [spec, sound]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 backdrop-blur-sm" onClick={onClose}>
      <div className="flex max-h-[96vh] w-full max-w-4xl flex-col gap-4 overflow-auto rounded-2xl bg-slate-900 p-4 md:flex-row" onClick={(e) => e.stopPropagation()}>
        <div className="relative mx-auto aspect-[9/16] h-[70vh] max-h-[760px] shrink-0 overflow-hidden rounded-xl bg-black">
          <canvas ref={cv} width={540} height={960} className="h-full w-full" />
          {loading && <div className="absolute inset-0 flex items-center justify-center bg-black/60 text-sm text-white">正在构建场景…</div>}
        </div>
        <div className="flex min-w-0 flex-1 flex-col gap-3 text-sm text-slate-200">
          <div className="flex items-start justify-between gap-3">
            <div className="text-xs uppercase tracking-wider text-sky-400">{spec.catLabel} · {dur ? dur.toFixed(1) + ' s' : ''}</div>
            <button onClick={onClose} className="rounded-lg bg-slate-700 px-3 py-1 text-xs hover:bg-slate-600">关闭 ✕</button>
          </div>
          <h3 className="text-lg font-bold leading-snug text-white">{spec.title}</h3>
          <div className="flex flex-wrap gap-2">
            <CopyButton text={spec.title} label="复制标题" />
            <CopyButton text={spec.description} label="复制描述" />
            <CopyButton text={spec.tags.join(', ')} label="复制标签" />
            <button onClick={() => setSound((s) => !s)} className="rounded-lg bg-slate-700 px-3 py-1.5 text-xs font-semibold hover:bg-slate-600">{sound ? '🔊 声音开' : '🔇 声音关'}</button>
          </div>
          <pre className="max-h-64 overflow-auto whitespace-pre-wrap rounded-lg bg-slate-800 p-3 text-xs leading-relaxed text-slate-300">{spec.description}</pre>
          <div className="text-xs text-slate-400">标签：{spec.tags.join(', ')}</div>
          <button
            disabled={busy}
            onClick={() => { onGenerate(); onClose(); }}
            className="mt-auto rounded-xl bg-gradient-to-r from-emerald-500 to-sky-500 px-4 py-3 text-base font-bold text-white shadow-lg disabled:opacity-50"
          >
            ⬇ 生成并下载这个视频
          </button>
        </div>
      </div>
    </div>
  );
}

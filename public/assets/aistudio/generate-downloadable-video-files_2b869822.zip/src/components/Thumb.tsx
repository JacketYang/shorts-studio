import { useEffect, useRef, useState } from 'react';
import type { VideoSpec } from '../engine/types';
import { buildScene, themeOf } from '../scenes';
import { drawStill } from '../engine/preview';

const cache = new Map<string, string>();
let chain: Promise<void> = Promise.resolve();

export function Thumb({ spec, onOpen }: { spec: VideoSpec; onOpen: () => void }) {
  const ref = useRef<HTMLButtonElement>(null);
  const [src, setSrc] = useState<string | undefined>(cache.get(spec.id));

  useEffect(() => {
    const cached = cache.get(spec.id);
    if (cached) {
      setSrc(cached);
      return;
    }
    setSrc(undefined);
    const el = ref.current;
    if (!el) return;
    let cancelled = false;
    const io = new IntersectionObserver(
      (es) => {
        if (!es[0].isIntersecting) return;
        io.disconnect();
        chain = chain.then(
          () =>
            new Promise<void>((res) => {
              setTimeout(() => {
                if (!cancelled) {
                  try {
                    const sc = buildScene(spec);
                    const cv = document.createElement('canvas');
                    cv.width = 270;
                    cv.height = 480;
                    drawStill(cv, sc, themeOf(spec), spec.hook, sc.duration * 0.55);
                    const u = cv.toDataURL('image/jpeg', 0.82);
                    cache.set(spec.id, u);
                    setSrc(u);
                  } catch (e) {
                    console.error('thumb', spec.id, e);
                  }
                }
                res();
              }, 15);
            }),
        );
      },
      { rootMargin: '300px' },
    );
    io.observe(el);
    return () => {
      cancelled = true;
      io.disconnect();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [spec.id]);

  return (
    <button ref={ref} onClick={onOpen} className="group relative block aspect-[9/16] w-full overflow-hidden rounded-xl bg-slate-800 text-left">
      {src ? (
        <img src={src} alt={spec.title} className="h-full w-full object-cover transition group-hover:scale-[1.03]" />
      ) : (
        <div className="flex h-full w-full items-center justify-center text-xs text-slate-500">加载缩略图…</div>
      )}
      <div className="absolute inset-0 flex items-center justify-center bg-black/0 opacity-0 transition group-hover:bg-black/35 group-hover:opacity-100">
        <span className="rounded-full bg-white/90 px-4 py-2 text-sm font-bold text-slate-900">▶ 预览 / 试听</span>
      </div>
    </button>
  );
}
